DbiProj2
=======
Teammates: 
Chaozhong Lian ( cl3190 )
Jinxi Zhao ( jz2540 )
=======

How to run the program:
1. type "make"
	 This compile the "SplashTable.java" and "probe.c", and generate "SplashTable.class" and "probe" files
2. type "./splash B R S h inputfile dumpfile < probefile > resultfile"
	 This run the java program with given B R S h and take input from probefile, then generate the resultfile
3. type "./probe dumpfile < probefile > resultfile"
	 This run the c program, output results to resultfile
